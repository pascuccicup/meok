package com.example.meoktionary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class showadmin extends AppCompatActivity {
MemberCollection memberCollection;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        memberCollection=MemberCollection.getInstance();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showadmin);
        ArrayList<String> arrayList= new ArrayList();
        for(int i=0; i<memberCollection.getMembers().size();i++) {
            arrayList.add(memberCollection.getMembers().get(i).getMember_id());
        }
        ArrayAdapter adapter= new ArrayAdapter(this,android.R.layout.simple_list_item_1,arrayList);
        ListView listView =(ListView)findViewById(R.id.list);
        listView.setAdapter(adapter);

    }

}
