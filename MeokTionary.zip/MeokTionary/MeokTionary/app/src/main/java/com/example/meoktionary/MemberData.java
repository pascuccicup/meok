package com.example.meoktionary;

public class MemberData {
    private String member_id;
    private String member_password;
    private String member_phone_number;

    public  MemberData(String id, String password, String phone_number){
        member_id=id;
        member_password=password;
        member_phone_number=phone_number;
    }
    public String getMember_id(){
        return member_id;
    }
    public  String getMember_password(){
        return  member_password;
    }
    public String getMember_phone_number(){
        return  member_phone_number;
    }
}
