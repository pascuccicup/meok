package com.example.meoktionary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class startActivity extends AppCompatActivity {
    MemberCollection memberCollection;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        memberCollection=MemberCollection.getInstance();
    }

    public void main_Activity(View view) {
        EditText edt_login = (EditText)findViewById(R.id.ID);
        EditText edt_password = (EditText)findViewById(R.id.PASSWORD);
        boolean ok_next=false;
        for (int i = 0; i < memberCollection.getMembers().size(); i++) {
            if (edt_login.getText().toString().equals(memberCollection.getMembers().get(i).getMember_id())) {
                for (int j = 0; j < memberCollection.getMembers().size(); j++) {
                    if (edt_password.getText().toString().equals(memberCollection.getMembers().get(j).getMember_password())) {
                        ok_next = true;
                    }
                }
            }
        }
        if(!ok_next)
            Toast.makeText(this,"PLEASE CHECK AND AGAIN",Toast.LENGTH_SHORT).show();
        else
        {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }

    public void signup_Activity(View view) {
        Intent intent=  new Intent(this, SignUpActivity.class);
        startActivity(intent);
    }

    public void showadmin(View view) {
        Intent intent = new Intent(this, showadmin.class);
        startActivity(intent);
    }
}
