package com.example.meoktionary;

import android.content.Intent;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;
import android.widget.EditText;




public class SignUpActivity extends AppCompatActivity {
    boolean ID_OK;
    boolean PHONE_OK;
    boolean PASSWORD_OK;
    MemberCollection memberCollection;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        ID_OK = false;
        PHONE_OK = false;
        PASSWORD_OK = false;
        memberCollection= MemberCollection.getInstance();
    }

    public void send_check_Message_ID(View view) {
        EditText edit_id = (EditText)findViewById(R.id.input_ID);
        if(edit_id.getText().toString().isEmpty()) {
            Toast.makeText(this, "ID IS NULL", Toast.LENGTH_SHORT).show();
        }
        else{
            if(!edit_id.getText().toString().equals("abc")) {
               Toast.makeText(this, "SUCESS ID", Toast.LENGTH_SHORT).show();
               ID_OK=true;
            }
         else {
             Toast.makeText(this, "FAILD ID", Toast.LENGTH_SHORT).show();
             ID_OK = false;
            }
        }
    }

    public void send_check_Message_PHONE(View view) {
        EditText edit_phone = (EditText)findViewById(R.id.input_PHONE_NUMBER);
        if(edit_phone.getText().toString().isEmpty()) {
            Toast.makeText(this, "PHONE NUMBER IS NULL", Toast.LENGTH_SHORT).show();
        }
        else {
            if (!edit_phone.getText().toString().equals("01000000000")) {
                Toast.makeText(this, "SUCESS NUMBER", Toast.LENGTH_SHORT).show();
                PHONE_OK = true;
            } else {
                PHONE_OK = false;
                Toast.makeText(this, "FAILD NUMBER", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void send_match_Message_PASSWORD(View view) {
        EditText edit_password = (EditText)findViewById(R.id.input_PASSWORD);
        EditText edit_password_MATCH =  (EditText)findViewById(R.id.input_PASSWORD_MATCH);
        if(edit_password.getText().toString().isEmpty()||edit_password_MATCH.getText().toString().isEmpty()){
            if(edit_password.getText().toString().isEmpty())
                Toast.makeText(this, "PASSWORD IS EMPTY", Toast.LENGTH_SHORT).show();
            if(edit_password_MATCH.getText().toString().isEmpty())
                Toast.makeText(this, "PASSWORD CHECK IS EMPTY", Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "PLEASE FILL BLANK", Toast.LENGTH_SHORT).show();
        }
        else {
            if (!edit_password.getText().toString().equals(edit_password_MATCH.getText().toString())) {
                Toast.makeText(this, "incorrect password", Toast.LENGTH_SHORT).show();
                PASSWORD_OK = false;
            } else {
                PASSWORD_OK = true;
                Toast.makeText(this, "correct password", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void createNewMember(View view) {
        EditText edit_id=(EditText)findViewById(R.id.input_ID);
        EditText edit_password=(EditText)findViewById(R.id.input_PASSWORD);
        EditText edit_phonenumber=(EditText)findViewById(R.id.input_PHONE_NUMBER);

        if (!PASSWORD_OK)
            Toast.makeText(this, "PASSWORD CHECK AGAIN", Toast.LENGTH_SHORT).show();
        else
        if(!ID_OK)
            Toast.makeText(this, "ID CHECK AGAIN", Toast.LENGTH_SHORT).show();
        else
        if(!PHONE_OK)
            Toast.makeText(this, "PHONE NUMBER CHECK AGAIN", Toast.LENGTH_SHORT).show();
        else {
            MemberData member = new MemberData(edit_id.getText().toString(),edit_password.getText().toString(),edit_phonenumber.getText().toString());
            memberCollection.getMembers().add(member);
            finish();
        }


    }

}
