package com.example.meoktionary;

import java.util.ArrayList;

public class MemberCollection {
    static private  MemberCollection instance;
    private ArrayList<MemberData> members;
    private MemberCollection(){
        members = new ArrayList();
    }
    public static MemberCollection getInstance() {
        if (instance == null) {
            instance = new MemberCollection();
        }
        return instance;
    }
    ArrayList<MemberData> getMembers(){
        return members;
    }
}
